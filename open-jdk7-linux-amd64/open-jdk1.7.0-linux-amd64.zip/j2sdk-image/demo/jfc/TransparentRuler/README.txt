
To run the Ruler demo:

  java -jar Ruler.jar

These instructions assume that this installation's version of the java
command is in your path.  If it isn't, then you should either
specify the complete path to the java command or update your
PATH environment variable as described in the installation
instructions for the Java(TM) SE Development Kit.

KNOWN ISSUES:
Context menu is clipped with the window shape. The issues are:
CR 7027486 JPopupMenu doesn't take window shape into account
